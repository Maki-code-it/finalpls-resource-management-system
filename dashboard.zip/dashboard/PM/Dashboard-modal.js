// Dashboard-modal.js - Modal Management for Allocate Hours
import { supabase } from "../../supabaseClient.js";

// Info map for allocation types
const infoMap = {
    'work': { class: 'info-work', icon: 'briefcase', text: 'Work Assignment' },
    'absent': { class: 'info-absent', icon: 'times-circle', text: 'Absent' },
    'leave': { class: 'info-leave', icon: 'calendar-times', text: 'Leave' },
    'holiday': { class: 'info-holiday', icon: 'star', text: 'Holiday' },
    'sick_leave': { class: 'info-sick', icon: 'medkit', text: 'Sick Leave' },
    'work_from_home': { class: 'info-wfh', icon: 'home', text: 'Work from Home' },
    'training': { class: 'info-training', icon: 'graduation-cap', text: 'Training' },
    'other': { class: 'info-other', icon: 'question-circle', text: 'Other' }
};

class AllocateHoursModal {
    constructor() {
        this.modal = null;
        this.selectedEmployee = null;
        this.selectedDay = null;
        this.selectedDate = null;
        this.currentAction = null;
        this.pmId = null;
    }

    // Bound DOM handlers to ensure correct `this` context
    _onQuickActionClick(e) {
        e.preventDefault();
        const action = e.currentTarget?.dataset?.action;
        this.handleQuickAction(action, e.currentTarget);
    }

    _onOtherActionsChange(e) {
        const action = e.target?.value;
        if (action) this.handleQuickAction(action, null);
    }

    _onHoursInput(e) {
        const val = parseFloat(e.target?.value);
        if (!Number.isNaN(val)) this.updateHoursIndicator(val);
    }

    init(pmId) {
        this.pmId = pmId;
        console.log('[MODAL] Initialized with PM ID:', this.pmId);
        this.modal = document.getElementById('allocateHoursModal');
        this.setupEventListeners();
    }

    setupEventListeners() {
        const closeBtn = document.getElementById('closeAllocateModal');
        if (closeBtn) closeBtn.addEventListener('click', this.close.bind(this));

        const cancelBtn = document.getElementById('cancelAllocate');
        if (cancelBtn) cancelBtn.addEventListener('click', this.close.bind(this));

        // Quick action buttons - Work and Absent
        document.querySelectorAll('.quick-action-btn-new').forEach(btn => {
            btn.addEventListener('click', this._onQuickActionClick.bind(this));
        });

        // Other actions dropdown
        const otherSelect = document.getElementById('otherActionsSelect');
        if (otherSelect) otherSelect.addEventListener('change', this._onOtherActionsChange.bind(this));

        // Hours input change
        const hoursInput = document.getElementById('hoursInput');
        if (hoursInput) hoursInput.addEventListener('input', this._onHoursInput.bind(this));

        // Form submission
        document.getElementById('allocateHoursForm')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveAllocation();
        });

        // Click outside to close
        this.modal?.addEventListener('click', (e) => {
            if (e.target === this.modal) {
                this.close();
            }
        });
    }

    handleQuickAction(action, buttonElement) {
        // Clear selection from buttons
        document.querySelectorAll('.quick-action-btn-new').forEach(btn => {
            btn.classList.remove('selected');
        });
        
        if (buttonElement) {
            buttonElement.classList.add('selected');
        }

        this.currentAction = action;

        if (action === 'work') {
            this.showWorkForm();
        } else if (action === 'absent') {
            this.showAbsentForm();
        } else if (action === 'leave') {
            this.showLeaveForm();
        } else if (action === 'holiday') {
            this.showHolidayForm();
        } else if (action === 'sick_leave') {
            this.showSickLeaveForm();
        } else if (action === 'work_from_home') {
            this.showWorkFromHomeForm();
        } else if (action === 'training') {
            this.showTrainingForm();
        } else if (action === 'other') {
            this.showOtherForm();
        }
    }

    async open(employeeName, day, weekStart) {
        this.selectedEmployee = employeeName;
        this.selectedDay = day;
        this.calculateSelectedDate(weekStart);

        // Display employee and day
        document.getElementById('selectedEmployee').textContent = employeeName;
        document.getElementById('selectedDay').textContent = day;

        // Check if day is already marked as absent/leave
        const canAllocate = await this.checkExistingAbsentLeave(employeeName);
        
        if (!canAllocate) {
            this.showMessage('This day is already marked as Absent/Leave/Holiday/Sick Leave. Cannot add more entries.', 'warning');
            return; // Don't open modal
        }

        // Fetch assignment type
        await this.fetchEmployeeAssignmentType(employeeName);

        // Reset form
        this.resetForm();

        // Show modal
        this.modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    close() {
        this.modal.classList.remove('active');
        document.body.style.overflow = '';
        this.resetForm();
    }

    resetForm() {
        document.getElementById('allocateHoursForm').reset();
        
        // Remove selected class from buttons
        document.querySelectorAll('.quick-action-btn-new').forEach(btn => btn.classList.remove('selected'));
        
        // Reset dropdown
        const otherSelect = document.getElementById('otherActionsSelect');
        if (otherSelect) otherSelect.value = '';
        
        // Hide all conditional groups
        this.hideElement('projectGroup');
        this.hideElement('hoursGroup');
        this.hideElement('taskGroup');
        this.hideElement('reasonGroup');
        this.hideElement('allocationInfo');
        
        // Reset project select required state
        const projectSelect = document.getElementById('projectSelect');
        if (projectSelect) projectSelect.required = false;
        
        this.currentAction = null;
    }

    calculateSelectedDate(weekStart) {
        const [year, month, day] = weekStart.split('-').map(Number);
        const dayMap = { 'Mon': 0, 'Tue': 1, 'Wed': 2, 'Thu': 3, 'Fri': 4 };
        const dayOffset = dayMap[this.selectedDay.split(',')[0]] || 0;
        
        const date = new Date(year, month - 1, day + dayOffset);
        this.selectedDate = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    }

    async fetchEmployeeAssignmentType(employeeName) {
        try {
            const { data: userData, error: userError } = await supabase
                .from('users')
                .select('id')
                .eq('name', employeeName)
                .single();

            if (userError) throw userError;

            const { data: assignment, error: assignError } = await supabase
                .from('project_assignments')
                .select('assignment_type')
                .eq('user_id', userData.id)
                .eq('status', 'assigned')
                .limit(1)
                .single();

            const assignmentType = assignment?.assignment_type || 'Full-Time';
            
            const employeeDisplay = document.getElementById('selectedEmployee');
            if (employeeDisplay) {
                employeeDisplay.innerHTML = `${employeeName} <span style="color: rgba(255,255,255,0.7); font-size: 0.85em;">(${assignmentType})</span>`;
            }
        } catch (error) {
            console.error('Error fetching assignment type:', error);
        }
    }

    async checkExistingAbsentLeave(employeeName) {
        try {
            const { data: userData, error: userError } = await supabase
                .from('users')
                .select('id')
                .eq('name', employeeName)
                .single();

            if (userError) throw userError;

            // Check for existing absent/leave entries
            const { data: existingLogs, error: logsError } = await supabase
                .from('worklogs')
                .select('work_type')
                .eq('user_id', userData.id)
                .eq('log_date', this.selectedDate)
                .in('work_type', ['absent', 'leave', 'holiday', 'sick_leave']);

            if (logsError) throw logsError;

            // If any absent/leave entry exists, prevent allocation
            return !existingLogs || existingLogs.length === 0;
        } catch (error) {
            console.error('Error checking existing entries:', error);
            return true; // Allow allocation on error
        }
    }

    showWorkForm() {
        this.currentAction = 'work';
        
        this.showElement('projectGroup');
        this.showElement('hoursGroup');
        this.showElement('taskGroup');
        this.hideElement('reasonGroup');
        this.showElement('allocationInfo');

        const hoursInput = document.getElementById('hoursInput');
        hoursInput.value = 8;
        hoursInput.max = 24;
        hoursInput.disabled = false;
        this.updateHoursIndicator(8);

        // Make project required for work
        const projectSelect = document.getElementById('projectSelect');
        if (projectSelect) projectSelect.required = true;

        this.loadEmployeeProjects();
        this.showAllocationInfo('work', 8);
    }

    showAbsentForm() {
        this.hideElement('projectGroup');
        this.hideElement('hoursGroup');
        this.hideElement('taskGroup');
        this.showElement('reasonGroup');
        this.showElement('allocationInfo');

        const projectSelect = document.getElementById('projectSelect');
        if (projectSelect) projectSelect.required = false;

        this.showAllocationInfo('absent', 0);
    }

    showLeaveForm() {
        this.hideElement('projectGroup');
        this.hideElement('taskGroup');
        this.hideElement('hoursGroup');
        this.showElement('reasonGroup');
        this.showElement('allocationInfo');

        const projectSelect = document.getElementById('projectSelect');
        if (projectSelect) projectSelect.required = false;

        document.getElementById('hoursInput').value = 8;
        
        this.showAllocationInfo('leave', 8);
    }

    showHolidayForm() {
        this.hideElement('projectGroup');
        this.hideElement('taskGroup');
        this.hideElement('hoursGroup');
        this.showElement('reasonGroup');
        this.showElement('allocationInfo');

        const projectSelect = document.getElementById('projectSelect');
        if (projectSelect) projectSelect.required = false;

        document.getElementById('hoursInput').value = 8;
        
        this.showAllocationInfo('holiday', 8);
    }

    showSickLeaveForm() {
        this.hideElement('projectGroup');
        this.hideElement('taskGroup');
        this.hideElement('hoursGroup');
        this.showElement('reasonGroup');
        this.showElement('allocationInfo');

        const projectSelect = document.getElementById('projectSelect');
        if (projectSelect) projectSelect.required = false;

        document.getElementById('hoursInput').value = 8;
        
        this.showAllocationInfo('sick_leave', 8);
    }

    showWorkFromHomeForm() {
        this.showElement('projectGroup');
        this.showElement('hoursGroup');
        this.showElement('taskGroup');
        this.hideElement('reasonGroup');
        this.showElement('allocationInfo');

        const hoursInput = document.getElementById('hoursInput');
        hoursInput.value = 8;
        hoursInput.max = 24;
        hoursInput.disabled = false;
        this.updateHoursIndicator(8);

        const projectSelect = document.getElementById('projectSelect');
        if (projectSelect) projectSelect.required = true;

        this.loadEmployeeProjects();
        this.showAllocationInfo('work_from_home', 8);
    }

    showTrainingForm() {
        this.hideElement('projectGroup');
        this.showElement('hoursGroup');
        this.showElement('taskGroup');
        this.hideElement('reasonGroup');
        this.showElement('allocationInfo');

        const hoursInput = document.getElementById('hoursInput');
        hoursInput.value = 8;
        hoursInput.max = 24;
        hoursInput.disabled = false;
        this.updateHoursIndicator(8);

        const projectSelect = document.getElementById('projectSelect');
        if (projectSelect) projectSelect.required = false;

        this.showAllocationInfo('training', 8);
    }

    showOtherForm() {
        this.hideElement('projectGroup');
        this.showElement('hoursGroup');
        this.hideElement('taskGroup');
        this.showElement('reasonGroup');
        this.showElement('allocationInfo');

        const hoursInput = document.getElementById('hoursInput');
        hoursInput.value = 0;
        hoursInput.max = 24;
        hoursInput.disabled = false;
        this.updateHoursIndicator(0);

        const projectSelect = document.getElementById('projectSelect');
        if (projectSelect) projectSelect.required = false;

        this.showAllocationInfo('other', 0);
    }

    updateHoursIndicator(hours) {
        const indicator = document.getElementById('hoursIndicator');
        if (indicator) {
            indicator.textContent = `${hours}h`;
            indicator.style.color = hours > 8 ? '#ff6b6b' : '#4ade80';
        }
    }

    showAllocationInfo(type, hours) {
        const infoElement = document.getElementById('allocationInfo');
        const textElement = document.getElementById('allocationInfoText');
        
        if (!infoElement || !textElement) return;
        
        infoElement.className = 'allocation-info';
        
        const info = infoMap[type];
        if (info) {
            infoElement.classList.add(info.class);
            textElement.innerHTML = `<i class="fas fa-${info.icon}"></i> <strong>${info.text}</strong>`;
        }
    }

    async loadEmployeeProjects() {
        const projectSelect = document.getElementById('projectSelect');
        if (!projectSelect) return;

        try {
            const { data: userData, error: userError } = await supabase
                .from('users')
                .select('id')
                .eq('name', this.selectedEmployee)
                .single();

            if (userError) throw userError;

            const userId = userData.id;

            const { data: assignments, error: assignError } = await supabase
                .from('project_assignments')
                .select(`
                    project_id,
                    projects (
                        id,
                        name,
                        created_by
                    )
                `)
                .eq('user_id', userId)
                .eq('status', 'assigned');

            if (assignError) throw assignError;

            console.log('[PROJECTS DEBUG] Raw assignments:', assignments);
            console.log('[PROJECTS DEBUG] Current PM ID:', this.pmId);

            const employeeProjects = assignments
                ?.map(a => ({
                    id: a.projects.id,
                    name: a.projects.name,
                    created_by: a.projects.created_by
                })) || [];

            console.log('[PROJECTS DEBUG] All employee projects:', employeeProjects);

            // Filter by PM ID or include all if pmId is not set
            const filteredProjects = this.pmId 
                ? employeeProjects.filter(p => p.created_by === this.pmId)
                : employeeProjects;

            console.log('[PROJECTS DEBUG] Filtered projects:', filteredProjects);

            const uniqueProjects = Array.from(
                new Map(filteredProjects.map(p => [p.id, p])).values()
            );

            projectSelect.innerHTML = '<option value="">Select Project</option>';
            
            if (uniqueProjects.length === 0) {
                const option = document.createElement('option');
                option.value = "";
                option.textContent = "No projects assigned yet";
                option.disabled = true;
                projectSelect.appendChild(option);
                console.warn('[PROJECTS DEBUG] No projects found for employee');
                return;
            }

            for (const project of uniqueProjects) {
                const { data: existingLogs, error: logError } = await supabase
                    .from('worklogs')
                    .select('id, hours')
                    .eq('user_id', userId)
                    .eq('project_id', project.id)
                    .eq('log_date', this.selectedDate);

                if (logError && logError.code !== 'PGRST116') {
                    console.error('Error checking existing worklog:', logError);
                }

                const option = document.createElement('option');
                option.value = project.id;
                
                if (existingLogs && existingLogs.length > 0) {
                    const totalHours = existingLogs.reduce((sum, log) => sum + parseFloat(log.hours), 0);
                    option.textContent = `${project.name} (Currently: ${totalHours}h)`;
                } else {
                    option.textContent = project.name;
                }
                
                projectSelect.appendChild(option);
            }
        } catch (error) {
            console.error('Error loading employee projects:', error);
            projectSelect.innerHTML = '<option value="">Error loading projects</option>';
        }
    }

    async getDefaultProjectForLeaveAbsent(userId) {
        try {
            const { data: assignments, error: assignError } = await supabase
                .from('project_assignments')
                .select(`
                    project_id,
                    projects (
                        id,
                        name,
                        created_by
                    )
                `)
                .eq('user_id', userId)
                .eq('status', 'assigned');

            if (assignError) throw assignError;

            const employeeProjects = assignments
                ?.map(a => ({
                    id: a.projects.id,
                    name: a.projects.name,
                    created_by: a.projects.created_by
                })) || [];

            // Filter by PM ID or include all if pmId is not set
            const filteredProjects = this.pmId 
                ? employeeProjects.filter(p => p.created_by === this.pmId)
                : employeeProjects;

            if (filteredProjects.length > 0) {
                return filteredProjects[0].id;
            }

            return null;
        } catch (error) {
            console.error('Error getting default project:', error);
            return null;
        }
    }

    async saveAllocation() {
        try {
            if (!this.currentAction) {
                this.showMessage('Please select an action (Work, Absent, or Other)', 'error');
                return;
            }

            let worklogData = {
                user_id: null,
                project_id: null,
                log_date: this.selectedDate,
                hours: 0,
                work_description: '',
                work_type: '',
                status: 'in progress'
            };

            const { data: userData, error: userError } = await supabase
                .from('users')
                .select('id')
                .eq('name', this.selectedEmployee)
                .single();

            if (userError) throw userError;
            worklogData.user_id = userData.id;

            // Check again before saving if it's an absent/leave type
            if (['absent', 'leave', 'holiday', 'sick_leave'].includes(this.currentAction)) {
                const canAllocate = await this.checkExistingAbsentLeave(this.selectedEmployee);
                if (!canAllocate) {
                    this.showMessage('This day is already marked as Absent/Leave/Holiday/Sick Leave. Cannot add duplicate entries.', 'error');
                    return;
                }
            }

            // Handle different actions
            if (this.currentAction === 'work') {
                const project = document.getElementById('projectSelect').value;
                const hours = parseFloat(document.getElementById('hoursInput').value);
                const task = document.getElementById('taskInput').value;

                if (!project) {
                    this.showMessage('Please select a project', 'error');
                    return;
                }

                if (hours <= 0 || hours > 24) {
                    this.showMessage('Hours must be greater than 0 and not exceed 24', 'error');
                    return;
                }

                const shouldContinue = await this.checkOvertimeWarning(userData.id, hours);
                if (!shouldContinue) return;

                worklogData.project_id = parseInt(project);
                worklogData.hours = hours;
                worklogData.work_description = task || 'Work assigned';
                worklogData.work_type = 'assigned';

            } else if (this.currentAction === 'absent') {
                const reason = document.getElementById('reasonInput').value;
                const defaultProject = await this.getDefaultProjectForLeaveAbsent(userData.id);
                
                if (!defaultProject) {
                    this.showMessage('Cannot mark absent: Employee must be assigned to at least one project', 'error');
                    return;
                }

                worklogData.project_id = defaultProject;
                worklogData.hours = 0;
                worklogData.work_description = reason || 'Absent';
                worklogData.work_type = 'absent';
                worklogData.status = 'absent';

            } else if (this.currentAction === 'leave') {
                const reason = document.getElementById('reasonInput').value;
                const defaultProject = await this.getDefaultProjectForLeaveAbsent(userData.id);
                
                if (!defaultProject) {
                    this.showMessage('Cannot mark leave: Employee must be assigned to at least one project', 'error');
                    return;
                }

                worklogData.project_id = defaultProject;
                worklogData.hours = 8;
                worklogData.work_description = reason || 'Leave';
                worklogData.work_type = 'leave';
                worklogData.status = 'leave';

            } else if (this.currentAction === 'holiday') {
                const reason = document.getElementById('reasonInput').value;
                const defaultProject = await this.getDefaultProjectForLeaveAbsent(userData.id);
                
                if (!defaultProject) {
                    this.showMessage('Cannot mark holiday: Employee must be assigned to at least one project', 'error');
                    return;
                }

                worklogData.project_id = defaultProject;
                worklogData.hours = 8;
                worklogData.work_description = reason || 'Holiday';
                worklogData.work_type = 'holiday';
                worklogData.status = 'leave';

            } else if (this.currentAction === 'sick_leave') {
                const reason = document.getElementById('reasonInput').value;
                const defaultProject = await this.getDefaultProjectForLeaveAbsent(userData.id);
                
                if (!defaultProject) {
                    this.showMessage('Cannot mark sick leave: Employee must be assigned to at least one project', 'error');
                    return;
                }

                worklogData.project_id = defaultProject;
                worklogData.hours = 8;
                worklogData.work_description = reason || 'Sick Leave';
                worklogData.work_type = 'sick_leave';
                worklogData.status = 'leave';

            } else if (this.currentAction === 'work_from_home') {
                const project = document.getElementById('projectSelect').value;
                const hours = parseFloat(document.getElementById('hoursInput').value);
                const task = document.getElementById('taskInput').value;

                if (!project) {
                    this.showMessage('Please select a project', 'error');
                    return;
                }

                if (hours <= 0 || hours > 24) {
                    this.showMessage('Hours must be greater than 0 and not exceed 24', 'error');
                    return;
                }

                worklogData.project_id = parseInt(project);
                worklogData.hours = hours;
                worklogData.work_description = `[WFH] ${task || 'Work from home'}`;
                worklogData.work_type = 'work_from_home';

            } else if (this.currentAction === 'training') {
                const hours = parseFloat(document.getElementById('hoursInput').value);
                const task = document.getElementById('taskInput').value;
                const defaultProject = await this.getDefaultProjectForLeaveAbsent(userData.id);
                
                if (!defaultProject) {
                    this.showMessage('Cannot mark training: Employee must be assigned to at least one project', 'error');
                    return;
                }

                if (hours <= 0 || hours > 24) {
                    this.showMessage('Hours must be greater than 0 and not exceed 24', 'error');
                    return;
                }

                worklogData.project_id = defaultProject;
                worklogData.hours = hours;
                worklogData.work_description = task || 'Training';
                worklogData.work_type = 'training';

            } else if (this.currentAction === 'other') {
                const hours = parseFloat(document.getElementById('hoursInput').value);
                const reason = document.getElementById('reasonInput').value;
                const defaultProject = await this.getDefaultProjectForLeaveAbsent(userData.id);
                
                if (!defaultProject) {
                    this.showMessage('Cannot save: Employee must be assigned to at least one project', 'error');
                    return;
                }

                if (!reason || reason.trim() === '') {
                    this.showMessage('Please provide a reason for other allocation', 'error');
                    return;
                }

                if (hours < 0 || hours > 24) {
                    this.showMessage('Hours must be between 0 and 24', 'error');
                    return;
                }

                worklogData.project_id = defaultProject;
                worklogData.hours = hours;
                worklogData.work_description = reason;
                worklogData.work_type = 'other';
            }

            // Final guard: ensure project_id is set (DB requires it)
            if (worklogData.project_id === null || typeof worklogData.project_id === 'undefined') {
                this.showMessage('Cannot save allocation: project is not specified', 'error');
                return;
            }

            const { error: worklogError } = await supabase
                .from('worklogs')
                .insert(worklogData);

            if (worklogError) throw worklogError;

            this.close();
            this.showMessage('Hours allocated successfully', 'success');
            
            window.dispatchEvent(new CustomEvent('allocationSaved'));

        } catch (error) {
            console.error('Error saving allocation:', error);
            this.showMessage('Failed to save allocation: ' + error.message, 'error');
        }
    }

    async checkOvertimeWarning(userId, newHours) {
        try {
            const { data: existingLogs, error: logsError } = await supabase
                .from('worklogs')
                .select('hours')
                .eq('user_id', userId)
                .eq('log_date', this.selectedDate);

            if (logsError) throw logsError;

            const currentDayTotal = existingLogs?.reduce((sum, log) => sum + parseFloat(log.hours || 0), 0) || 0;
            const newTotal = currentDayTotal + newHours;

            if (newTotal > 8 && currentDayTotal <= 8) {
                const overtimeHours = newTotal - 8;
                const confirmed = confirm(
                    `This will result in ${overtimeHours.toFixed(1)}h overtime for ${this.selectedEmployee} on ${this.selectedDay}.\n\n` +
                    `Current: ${currentDayTotal}h\n` +
                    `Adding: ${newHours}h\n` +
                    `New Total: ${newTotal}h\n\n` +
                    `Do you want to continue?`
                );
                
                return confirmed;
            }

            return true;
        } catch (error) {
            console.error('Error checking overtime:', error);
            return true;
        }
    }

    showMessage(message, type) {
        window.dispatchEvent(new CustomEvent('showMessage', {
            detail: { message, type }
        }));
    }

    showElement(id) {
        const element = document.getElementById(id);
        if (element) element.style.display = 'block';
    }

    hideElement(id) {
        const element = document.getElementById(id);
        if (element) element.style.display = 'none';
    }
}

export const allocateHoursModal = new AllocateHoursModal();