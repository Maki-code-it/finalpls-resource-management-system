// PROJECT MANAGER (PM) Dashboard.js 
import { supabase } from "../../supabaseClient.js";
import { allocateHoursModal } from "./Dashboard-modal.js";

// ============================================
// USER NAME DISPLAY UTILITY
// ============================================

async function updateUserNameDisplayEnhanced() {
    const userNameElement = document.getElementById('userName');
    const userAvatarElement = document.querySelector('.user-avatar');
    
    if (!userNameElement) {
        console.warn('[USER DISPLAY] userName element not found');
        return;
    }

    try {
        const loggedUser = JSON.parse(localStorage.getItem('loggedUser') || '{}');
        let displayName = '';
        
        if (loggedUser.name) {
            displayName = loggedUser.name;
            userNameElement.textContent = displayName;
            console.log('[USER DISPLAY] User name updated to:', displayName);
        } else if (loggedUser.email) {
            try {
                const { data: userData, error } = await supabase
                    .from('users')
                    .select('name')
                    .eq('email', loggedUser.email)
                    .single();
                
                if (!error && userData && userData.name) {
                    displayName = userData.name;
                    userNameElement.textContent = displayName;
                    loggedUser.name = userData.name;
                    localStorage.setItem('loggedUser', JSON.stringify(loggedUser));
                    console.log('[USER DISPLAY] User name fetched from Supabase:', displayName);
                } else {
                    displayName = loggedUser.email.split('@')[0];
                    userNameElement.textContent = displayName;
                }
            } catch (dbError) {
                console.error('[USER DISPLAY] Error fetching from Supabase:', dbError);
                displayName = loggedUser.email.split('@')[0];
                userNameElement.textContent = displayName;
            }
        } else {
            displayName = 'Project Manager';
            userNameElement.textContent = displayName;
            console.warn('[USER DISPLAY] No user information found');
        }
        
        if (userAvatarElement && displayName) {
            const initials = displayName.split(' ')
                .map(word => word.charAt(0).toUpperCase())
                .join('')
                .substring(0, 2);
            
            userAvatarElement.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(displayName)}&background=000&color=fff`;
            userAvatarElement.alt = initials;
            console.log('[USER DISPLAY] Avatar updated with initials:', initials);
        }
    } catch (error) {
        console.error('[USER DISPLAY] Error updating user name:', error);
        userNameElement.textContent = 'Project Manager';
    }
}

// ============================================
// MODAL UTILITIES
// ============================================

class ModalManager {
    static show(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
    }

    static hide(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('active');
            document.body.style.overflow = '';
        }
    }

    static showLoading() {
        this.show('loadingOverlay');
    }

    static hideLoading() {
        this.hide('loadingOverlay');
    }
}

// ============================================
// MESSAGE UTILITIES
// ============================================

class MessageManager {
    static show(message, type = 'info') {
        const container = document.getElementById('messageContainer');
        if (!container) return;

        const messageBox = document.createElement('div');
        messageBox.className = `message-box ${type}`;

        const iconMap = {
            success: 'fa-check-circle',
            error: 'fa-exclamation-circle',
            warning: 'fa-exclamation-triangle',
            info: 'fa-info-circle'
        };

        const icon = document.createElement('i');
        icon.className = `fas ${iconMap[type]}`;

        const text = document.createElement('span');
        text.textContent = message;

        const closeBtn = document.createElement('button');
        closeBtn.className = 'message-close';
        closeBtn.innerHTML = '<i class="fas fa-times"></i>';
        closeBtn.addEventListener('click', () => messageBox.remove());

        messageBox.appendChild(icon);
        messageBox.appendChild(text);
        messageBox.appendChild(closeBtn);

        container.appendChild(messageBox);

        setTimeout(() => {
            messageBox.remove();
        }, 5000);
    }

    static success(message) {
        this.show(message, 'success');
    }

    static error(message) {
        this.show(message, 'error');
    }

    static warning(message) {
        this.show(message, 'warning');
    }

    static info(message) {
        this.show(message, 'info');
    }
}

// ============================================
// UTILITY FUNCTIONS
// ============================================

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function formatStatus(status) {
    const statusMap = {
        'active': 'Active',
        'ongoing': 'Ongoing',
        'planning': 'Planning',
        'completed': 'Completed',
        'on-hold': 'On Hold',
        'pending': 'Pending',
        'cancelled': 'Cancelled'
    };
    return statusMap[status] || status;
}

// ============================================
// PM DATA SERVICE - SUPABASE INTEGRATION
// ============================================

class PMDataService {
    constructor() {
        this.currentPMId = null;
        this.currentPMEmail = null;
        this.cache = {
            projects: null,
            teamMembers: null,
            timestamp: null
        };
        this.cacheTimeout = 30000; // 30 seconds cache
    }

    async initialize() {
        const loggedUser = JSON.parse(localStorage.getItem('loggedUser') || '{}');
        
        if (loggedUser.email) {
            this.currentPMEmail = loggedUser.email;
            
            const { data: userData, error } = await supabase
                .from('users')
                .select('id, name, email')
                .eq('email', this.currentPMEmail)
                .eq('role', 'project_manager')
                .single();

            if (error) {
                console.error('[PM DATA SERVICE] Error fetching PM user:', error);
                throw error;
            }

            this.currentPMId = userData.id;
            console.log('[PM DATA SERVICE] Initialized for PM:', userData);
        } else {
            throw new Error('No logged in user found');
        }
    }

    // Cache helper
    isCacheValid() {
        if (!this.cache.timestamp) return false;
        return (Date.now() - this.cache.timestamp) < this.cacheTimeout;
    }

    clearCache() {
        this.cache = {
            projects: null,
            teamMembers: null,
            timestamp: null
        };
    }

    async getDashboardStats() {
        try {
            console.log('[PM DATA SERVICE] Fetching dashboard stats for PM:', this.currentPMId);

            const { data: projects, error: projError } = await supabase
                .from('projects')
                .select('id, status')
                .eq('created_by', this.currentPMId)
                .in('status', ['pending', 'ongoing', 'active']);

            if (projError) throw projError;

            const activeProjects = projects?.length || 0;
            const projectIds = projects?.map(p => p.id) || [];

            // Parallel fetch for better performance
            const [assignmentsResult, worklogsResult] = await Promise.all([
                supabase
                    .from('project_assignments')
                    .select('user_id, assigned_hours')
                    .in('project_id', projectIds)
                    .eq('status', 'assigned'),
                (async () => {
                    const today = new Date();
                    const day = today.getDay();
                    const diff = today.getDate() - day + (day === 0 ? -6 : 1);
                    const startOfWeek = new Date(today.getFullYear(), today.getMonth(), diff);
                    const endOfWeek = new Date(startOfWeek);
                    endOfWeek.setDate(startOfWeek.getDate() + 4);

                    const startDateStr = `${startOfWeek.getFullYear()}-${String(startOfWeek.getMonth() + 1).padStart(2, '0')}-${String(startOfWeek.getDate()).padStart(2, '0')}`;
                    const endDateStr = `${endOfWeek.getFullYear()}-${String(endOfWeek.getMonth() + 1).padStart(2, '0')}-${String(endOfWeek.getDate()).padStart(2, '0')}`;

                    return await supabase
                        .from('worklogs')
                        .select('hours')
                        .in('project_id', projectIds)
                        .gte('log_date', startDateStr)
                        .lte('log_date', endDateStr);
                })()
            ]);

            if (assignmentsResult.error) throw assignmentsResult.error;
            if (worklogsResult.error) throw worklogsResult.error;

            const assignments = assignmentsResult.data;
            const worklogs = worklogsResult.data;

            const uniqueTeamMembers = [...new Set(assignments?.map(a => a.user_id) || [])];
            const teamMembers = uniqueTeamMembers.length;

            const totalHours = worklogs?.reduce((sum, log) => sum + parseFloat(log.hours || 0), 0) || 0;

            const totalAssignedHours = assignments?.reduce((sum, a) => sum + parseInt(a.assigned_hours || 0), 0) || 0;
            const maxPossibleHours = teamMembers * 40;
            const teamUtilization = maxPossibleHours > 0 ? Math.round((totalAssignedHours / maxPossibleHours) * 100) : 0;

            console.log('[PM DATA SERVICE] Stats:', { activeProjects, teamMembers, totalHours, teamUtilization });

            return {
                activeProjects,
                teamMembers,
                totalHours: Math.round(totalHours),
                teamUtilization
            };
        } catch (error) {
            console.error('[PM DATA SERVICE] Error fetching stats:', error);
            return {
                activeProjects: 0,
                teamMembers: 0,
                totalHours: 0,
                teamUtilization: 0
            };
        }
    }

    async getProjects(forceRefresh = false) {
        try {
            // Use cache if valid
            if (!forceRefresh && this.isCacheValid() && this.cache.projects) {
                console.log('[PM DATA SERVICE] Using cached projects');
                return this.cache.projects;
            }

            console.log('[PM DATA SERVICE] Fetching projects for PM:', this.currentPMId);

            const { data: projects, error } = await supabase
                .from('projects')
                .select(`
                    id,
                    name,
                    description,
                    status,
                    priority,
                    start_date,
                    end_date,
                    duration_days
                `)
                .eq('created_by', this.currentPMId)
                .in('status', ['pending', 'ongoing', 'active'])
                .order('created_at', { ascending: false });

            if (error) throw error;

            this.cache.projects = projects || [];
            this.cache.timestamp = Date.now();

            console.log('[PM DATA SERVICE] Projects fetched:', projects?.length || 0);
            return projects || [];
        } catch (error) {
            console.error('[PM DATA SERVICE] Error fetching projects:', error);
            return [];
        }
    }

    async getTeamMembers(forceRefresh = false) {
        try {
            // Use cache if valid
            if (!forceRefresh && this.isCacheValid() && this.cache.teamMembers) {
                console.log('[PM DATA SERVICE] Using cached team members');
                return this.cache.teamMembers;
            }

            console.log('[PM DATA SERVICE] Fetching team members for PM:', this.currentPMId);

            const { data: projects, error: projError } = await supabase
                .from('projects')
                .select('id')
                .eq('created_by', this.currentPMId)
                .in('status', ['pending', 'ongoing', 'active']);

            if (projError) throw projError;
            
            const projectIds = projects?.map(p => p.id) || [];

            if (projectIds.length === 0) {
                this.cache.teamMembers = [];
                return [];
            }

            const { data: assignments, error: assignError } = await supabase
                .from('project_assignments')
                .select(`
                    user_id,
                    role_in_project,
                    users (
                        id,
                        name,
                        email,
                        user_details (
                            job_title,
                            status,
                            profile_pic
                        )
                    )
                `)
                .in('project_id', projectIds)
                .eq('status', 'assigned');

            if (assignError) throw assignError;

            const uniqueMembers = {};
            assignments?.forEach(assignment => {
                const user = assignment.users;
                if (user && !uniqueMembers[user.id]) {
                    const userDetails = user.user_details?.[0];
                    
                    const profilePic = userDetails?.profile_pic;
                    const avatar = (profilePic && profilePic.trim() !== '') 
                        ? profilePic 
                        : `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=4A90E2&color=fff`;
        
                    uniqueMembers[user.id] = {
                        id: user.id,
                        name: user.name,
                        role: userDetails?.job_title || assignment.role_in_project || 'Team Member',
                        email: user.email,
                        status: userDetails?.status || 'Available',
                        avatar: avatar 
                    };
                }
            });

            const teamMembers = Object.values(uniqueMembers);
            this.cache.teamMembers = teamMembers;
            this.cache.timestamp = Date.now();

            console.log('[PM DATA SERVICE] Team members fetched:', teamMembers.length);
            return teamMembers;
        } catch (error) {
            console.error('[PM DATA SERVICE] Error fetching team members:', error);
            return [];
        }
    }

    async getWeeklyAllocation(weekStart) {
    try {
        console.log('[PM DATA SERVICE] Fetching weekly allocation for week:', weekStart);

        const [year, month, day] = weekStart.split('-').map(Number);
        
        const dates = [];
        const dateMap = {};
        
        for (let i = 0; i < 5; i++) {
            const currentDate = new Date(year, month - 1, day + i);
            const dateStr = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(currentDate.getDate()).padStart(2, '0')}`;
            dates.push(dateStr);
            dateMap[dateStr] = i;
        }

        console.log('[PM DATA SERVICE] Week dates:', dates);

        // Parallel fetch
        const [teamMembers, projectsResult, worklogsResult] = await Promise.all([
            this.getTeamMembers(),
            supabase
                .from('projects')
                .select('id')
                .eq('created_by', this.currentPMId)
                .in('status', ['pending', 'ongoing', 'active']),
            (async () => {
                const { data: projects } = await supabase
                    .from('projects')
                    .select('id')
                    .eq('created_by', this.currentPMId)
                    .in('status', ['pending', 'ongoing', 'active']);
                
                const projectIds = projects?.map(p => p.id) || [];
                
                if (projectIds.length === 0) return { data: [], error: null };
                
                // Fetch worklogs WITH work_type
                return await supabase
                    .from('worklogs')
                    .select('user_id, log_date, hours, work_type')
                    .in('project_id', projectIds)
                    .in('log_date', dates);
            })()
        ]);

        if (projectsResult.error) throw projectsResult.error;
        if (worklogsResult.error) throw worklogsResult.error;

        const worklogs = worklogsResult.data || [];

        console.log('[PM DATA SERVICE] Worklogs fetched:', worklogs);

        const allocation = teamMembers.map(member => {
            const memberLogs = worklogs?.filter(log => log.user_id === member.id) || [];
            
            const dailyData = {
                mon: { hours: 0, types: [] },
                tue: { hours: 0, types: [] },
                wed: { hours: 0, types: [] },
                thu: { hours: 0, types: [] },
                fri: { hours: 0, types: [] }
            };

            memberLogs.forEach(log => {
                const logDate = log.log_date;
                const dayIndex = dateMap[logDate];
                
                const dayKeys = ['mon', 'tue', 'wed', 'thu', 'fri'];
                const dayKey = dayKeys[dayIndex];
                
                if (dayKey && dailyData.hasOwnProperty(dayKey)) {
                    dailyData[dayKey].hours += parseFloat(log.hours || 0);
                    
                    // Track work types
                    if (log.work_type && !dailyData[dayKey].types.includes(log.work_type)) {
                        dailyData[dayKey].types.push(log.work_type);
                    }
                    
                    console.log(`[PM DATA SERVICE] ${member.name} - ${logDate} (${dayKey}, index ${dayIndex}): ${log.hours}h [${log.work_type}]`);
                }
            });

            return {
                employee: member.name,
                role: member.role,
                avatar: member.avatar,
                mon: dailyData.mon,
                tue: dailyData.tue,
                wed: dailyData.wed,
                thu: dailyData.thu,
                fri: dailyData.fri
            };
        });

        console.log('[PM DATA SERVICE] Weekly allocation fetched:', allocation);
        return allocation;
    } catch (error) {
        console.error('[PM DATA SERVICE] Error fetching weekly allocation:', error);
        return [];
    }
}

    async getAvailableTeamMembers() {
        try {
            console.log('[PM DATA SERVICE] Fetching available team members');

            // Parallel fetch
            const [teamMembers, projectsResult] = await Promise.all([
                this.getTeamMembers(),
                supabase
                    .from('projects')
                    .select('id')
                    .eq('created_by', this.currentPMId)
                    .in('status', ['pending', 'ongoing', 'active'])
            ]);

            if (projectsResult.error) throw projectsResult.error;

            const projectIds = projectsResult.data?.map(p => p.id) || [];

            if (projectIds.length === 0) return [];

            const { data: assignments, error: assignError } = await supabase
                .from('project_assignments')
                .select('user_id, assigned_hours')
                .in('project_id', projectIds)
                .eq('status', 'assigned');

            if (assignError) throw assignError;

            const userAssignedHours = {};
            assignments?.forEach(assignment => {
                if (!userAssignedHours[assignment.user_id]) {
                    userAssignedHours[assignment.user_id] = 0;
                }
                userAssignedHours[assignment.user_id] += parseInt(assignment.assigned_hours || 0);
            });

            const availableMembers = teamMembers
                .map(member => {
                    const assignedHours = userAssignedHours[member.id] || 0;
                    const availableHours = 40 - assignedHours;
                    const utilization = Math.round((assignedHours / 40) * 100);

                    return {
                        ...member,
                        assignedHours,
                        availableHours,
                        utilization,
                        utilizationLevel: assignedHours >= 40 ? 'high' : assignedHours >= 20 ? 'medium' : 'low'
                    };
                })
                .filter(member => member.availableHours > 0)
                .sort((a, b) => b.availableHours - a.availableHours);

            console.log('[PM DATA SERVICE] Available team members:', availableMembers.length);
            return availableMembers;
        } catch (error) {
            console.error('[PM DATA SERVICE] Error fetching available team members:', error);
            return [];
        }
    }
}

// ============================================
// DASHBOARD APP
// ============================================

class DashboardApp {
    constructor() {
        this.dataService = new PMDataService();
        this.currentWeek = this.getCurrentWeekStart();
        this.selectedCell = null;
        this.isLoading = false;
    }

    getCurrentWeekStart() {
        const today = new Date();
        const day = today.getDay();
        const diff = today.getDate() - day + (day === 0 ? -6 : 1);
        const monday = new Date(today.getFullYear(), today.getMonth(), diff);
        return `${monday.getFullYear()}-${String(monday.getMonth() + 1).padStart(2, '0')}-${String(monday.getDate()).padStart(2, '0')}`;
    }

    async init() {
        try {
            if (this.isLoading) return;
            this.isLoading = true;

            ModalManager.showLoading();
            
            // Initialize data service first
            await this.dataService.initialize();
            
            // Initialize the modal with PM ID
            allocateHoursModal.init(this.dataService.currentPMId);
            
            // Setup listeners immediately
            this.setupEventListeners();
            
            // Update user display in parallel with data loading
            updateUserNameDisplayEnhanced();
            
            // Load dashboard data
            await this.loadDashboard();
            
            this.isLoading = false;
            ModalManager.hideLoading();
        } catch (error) {
            this.isLoading = false;
            ModalManager.hideLoading();
            console.error('[DASHBOARD APP] Initialization error:', error);
            MessageManager.error('Failed to initialize dashboard. Please login again.');
            setTimeout(() => {
                window.location.href = "/login/HTML_Files/login.html";
            }, 2000);
        }
    }

    setupEventListeners() {
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => this.openLogoutModal());
        }

        const cancelLogout = document.getElementById('cancelLogout');
        const confirmLogout = document.getElementById('confirmLogout');
        
        if (cancelLogout) {
            cancelLogout.addEventListener('click', () => ModalManager.hide('logoutModal'));
        }
        if (confirmLogout) {
            confirmLogout.addEventListener('click', () => this.handleLogout());
        }

        const prevWeek = document.getElementById('prevWeek');
        const nextWeek = document.getElementById('nextWeek');
        const weekSelect = document.getElementById('weekSelect');

        if (prevWeek) {
            prevWeek.addEventListener('click', () => this.changeWeek(-1));
        }
        if (nextWeek) {
            nextWeek.addEventListener('click', () => this.changeWeek(1));
        }
        if (weekSelect) {
            weekSelect.addEventListener('change', (e) => {
                this.currentWeek = e.target.value;
                this.loadWeeklyAllocation();
            });
        }

        // Handle cell clicks - open modal
        document.addEventListener('click', (e) => {
            const cell = e.target.closest('.hours-cell');
            if (cell) {
                this.openAllocateModal(cell);
            }
        });

        // Listen for modal events
        window.addEventListener('allocationSaved', () => {
            this.handleAllocationSaved();
        });

        window.addEventListener('showMessage', (e) => {
            MessageManager.show(e.detail.message, e.detail.type);
        });

        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay && overlay.id !== 'allocateHoursModal') {
                    overlay.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        });
    }

    async loadDashboard() {
        try {
            // Generate week options first (no API call)
            this.generateWeekOptions();
            
            // Parallel load all dashboard data for better performance
            const [stats, projects] = await Promise.all([
                this.dataService.getDashboardStats(),
                this.dataService.getProjects()
            ]);

            // Update UI with fetched data
            this.updateStats(stats);

            // Load allocation and available members in parallel
            await Promise.all([
                this.loadWeeklyAllocation(),
                this.loadAvailableTeamMembers()
            ]);

        } catch (error) {
            console.error('[DASHBOARD APP] Error loading dashboard:', error);
            MessageManager.error('Failed to load dashboard data');
        }
    }

    updateStats(stats) {
        const elements = {
            activeProjects: document.getElementById('activeProjects'),
            teamMembers: document.getElementById('teamMembers'),
            totalHours: document.getElementById('totalHours'),
            teamUtilization: document.getElementById('teamUtilization')
        };

        if (elements.activeProjects) elements.activeProjects.textContent = stats.activeProjects;
        if (elements.teamMembers) elements.teamMembers.textContent = stats.teamMembers;
        if (elements.totalHours) elements.totalHours.textContent = stats.totalHours + 'h';
        if (elements.teamUtilization) elements.teamUtilization.textContent = stats.teamUtilization + '%';
    }

    async loadWeeklyAllocation() {
        try {
            const allocation = await this.dataService.getWeeklyAllocation(this.currentWeek);
            this.renderWeeklyAllocation(allocation);
        } catch (error) {
            console.error('[DASHBOARD APP] Error loading weekly allocation:', error);
            MessageManager.error('Failed to load weekly allocation');
        }
    }

    updateTableHeaders() {
        const weekSelect = document.getElementById('weekSelect');
        if (!weekSelect) return;

        const [year, month, day] = weekSelect.value.split('-').map(Number);
        const dayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
        
        const thead = document.querySelector('.allocation-table thead tr');
        if (!thead) return;

        for (let i = 0; i < 5; i++) {
            const currentDate = new Date(year, month - 1, day + i);
            
            const monthName = currentDate.toLocaleDateString('en-US', { month: 'short' });
            const dateNum = currentDate.getDate();
            
            const thIndex = i + 1;
            const th = thead.children[thIndex];
            if (th) {
                th.innerHTML = `${dayNames[i]}<br><span class="date-label">${monthName} ${dateNum}</span>`;
            }
        }
    }


    renderWeeklyAllocation(allocation) {
        const tbody = document.getElementById('allocationTableBody');
        if (!tbody) return;

        this.updateTableHeaders();

        if (allocation.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="7" style="text-align: center; padding: 40px; color: #6c757d;">
                        <i class="fas fa-users" style="font-size: 48px; opacity: 0.3; margin-bottom: 16px;"></i>
                        <p>No team members assigned yet</p>
                    </td>
                </tr>
            `;
            return;
        }

        tbody.innerHTML = '';

        allocation.forEach(member => {
            const row = document.createElement('tr');
            
            const days = ['mon', 'tue', 'wed', 'thu', 'fri'];
            const dayLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
            
            // Calculate total hours
            const totalHours = days.reduce((sum, day) => {
                return sum + (member[day]?.hours || 0);
            }, 0);
            
            row.innerHTML = `
                <td class="employee-cell">
                    <div class="employee-info">
                        <img src="${member.avatar}" alt="${member.employee}" class="employee-avatar-small">
                        <div>
                            <div class="employee-name">${member.employee}</div>
                            <div class="employee-role">${member.role}</div>
                        </div>
                    </div>
                </td>
                ${days.map((day, index) => {
                    const dayData = member[day] || { hours: 0, types: [] };
                    const hours = dayData.hours || 0;
                    const workTypes = dayData.types || [];
                    
                    let cellClass = 'empty';
                    let displayHtml = '';
                    
                    // Check work type categories
                    const isAbsent = workTypes.includes('absent');
                    const isLeaveType = workTypes.some(type => 
                        ['leave', 'holiday'].includes(type)
                    );
                    
                    // Get work type label
                    const workTypeLabel = this.getWorkTypeLabel(workTypes);
                    
                    if (isAbsent) {
                        // ABSENT: Show ---- and "Absent" label in gray (similar to holiday style)
                        cellClass = 'absent-day';
                        displayHtml = `
                            <div class="hours-value">---</div>
                            ${workTypeLabel ? `<div class="work-type-label">${workTypeLabel}</div>` : ''}
                        `;
                    } else if (isLeaveType) {
                        // LEAVE/HOLIDAY
                        cellClass = 'leave-day';
                        displayHtml = `
                            <div class="hours-value">8h</div>
                            ${workTypeLabel ? `<div class="work-type-label">${workTypeLabel}</div>` : ''}
                        `;
                    } else if (hours > 8) {
                        // OVERTIME: Red with warning
                        cellClass = 'overtime';
                        const overtimeHours = hours - 8;
                        displayHtml = `
                            <div class="hours-value">${hours}h</div>
                            <div class="overtime-label">+${overtimeHours}h OT</div>
                        `;
                    } else if (hours === 8) {
                        // FULL WORK DAY: Blue with 8h
                        cellClass = 'work-day';
                        displayHtml = `
                            <div class="hours-value">8h</div>
                        `;
                    } else if (hours > 0) {
                        // PARTIAL WORK: Blue with actual hours
                        cellClass = 'work-day';
                        displayHtml = `
                            <div class="hours-value">${hours}h</div>
                        `;
                    } else {
                        // EMPTY: Gray
                        displayHtml = `<div class="hours-value">0h</div>`;
                    }
                    
                    return `
                        <td class="hours-cell ${cellClass}" data-employee="${member.employee}" data-day="${dayLabels[index]}">
                            ${displayHtml}
                        </td>
                    `;
                }).join('')}
                <td class="total-cell">${totalHours}h</td>
            `;
            
            tbody.appendChild(row);
        });
    }

    getWorkTypeLabel(workTypes) {
        if (!workTypes || workTypes.length === 0) return '';
        
        // Work type display mapping - removed "assigned" display
        const workTypeMap = {
            'assigned': '',  // Don't show label for regular work
            'absent': 'Absent',
            'leave': 'Leave',
            'holiday': 'Holiday',
            'sick_leave': 'Sick',
            'other': 'Other'
        };
        
        // Filter out 'assigned' type
        const displayTypes = workTypes.filter(type => type !== 'assigned');
        
        if (displayTypes.length === 0) return '';
        
        // If multiple types, show count
        if (displayTypes.length > 1) {
            const primaryType = displayTypes[0];
            return `${workTypeMap[primaryType] || primaryType} +${displayTypes.length - 1}`;
        }
        
        // Single type
        return workTypeMap[displayTypes[0]] || displayTypes[0];
    }
    async loadAvailableTeamMembers() {
        try {
            const availableMembers = await this.dataService.getAvailableTeamMembers();
            this.renderAvailableTeamMembers(availableMembers);
        } catch (error) {
            console.error('[DASHBOARD APP] Error loading available team members:', error);
        }
    }

    renderAvailableTeamMembers(members) {
        const container = document.querySelector('.available-grid');
        if (!container) return;

        if (members.length === 0) {
            container.innerHTML = `
                <div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #6c757d;">
                    <i class="fas fa-users" style="font-size: 48px; opacity: 0.3; margin-bottom: 16px;"></i>
                    <p>All team members are fully allocated</p>
                </div>
            `;
            return;
        }

        container.innerHTML = '';
        
        members.forEach(member => {
            const card = document.createElement('div');
            card.className = 'available-card';
            
            card.innerHTML = `
                <img src="${member.avatar}" alt="${member.name}" class="available-avatar">
                <div class="available-info">
                    <h4>${member.name}</h4>
                    <p class="available-role">${member.role}</p>
                    <div class="utilization-badge ${member.utilizationLevel}">
                        <i class="fas fa-circle"></i> ${member.utilization}% Utilization
                    </div>
                    <p class="available-hours">${member.availableHours}h available</p>
                </div>
            `;
            
            container.appendChild(card);
        });
    }

    generateWeekOptions() {
        const weekSelect = document.getElementById('weekSelect');
        if (!weekSelect) return;

        const today = new Date();
        const currentDay = today.getDay();
        const diff = today.getDate() - currentDay + (currentDay === 0 ? -6 : 1);
        const currentMonday = new Date(today.getFullYear(), today.getMonth(), diff);
        
        weekSelect.innerHTML = '';
        
        for (let i = -10; i <= 0; i++) {
            const weekStart = new Date(currentMonday);
            weekStart.setDate(currentMonday.getDate() + (i * 7));
            
            const weekEnd = new Date(weekStart);
            weekEnd.setDate(weekStart.getDate() + 4);
            
            const startMonth = weekStart.toLocaleDateString('en-US', { month: 'short' });
            const startDay = weekStart.getDate();
            const startYear = weekStart.getFullYear();
            
            const endMonth = weekEnd.toLocaleDateString('en-US', { month: 'short' });
            const endDay = weekEnd.getDate();
            const endYear = weekEnd.getFullYear();
            
            const option = document.createElement('option');
            option.value = `${weekStart.getFullYear()}-${String(weekStart.getMonth() + 1).padStart(2, '0')}-${String(weekStart.getDate()).padStart(2, '0')}`;
            
            if (startMonth === endMonth && startYear === endYear) {
                option.textContent = `Week of ${startMonth} ${startDay} - ${endDay}, ${startYear}`;
            } else if (startYear === endYear) {
                option.textContent = `Week of ${startMonth} ${startDay} - ${endMonth} ${endDay}, ${startYear}`;
            } else {
                option.textContent = `Week of ${startMonth} ${startDay}, ${startYear} - ${endMonth} ${endDay}, ${endYear}`;
            }
            
            if (i === 0) {
                option.selected = true;
            }
            
            weekSelect.appendChild(option);
        }
        
        this.currentWeek = weekSelect.value;
    }

    changeWeek(direction) {
        const weekSelect = document.getElementById('weekSelect');
        if (!weekSelect) return;

        const currentIndex = weekSelect.selectedIndex;
        const newIndex = currentIndex + direction;

        if (newIndex >= 0 && newIndex < weekSelect.options.length) {
            weekSelect.selectedIndex = newIndex;
            this.currentWeek = weekSelect.value;
            this.loadWeeklyAllocation();
        }
    }

    // Open modal - delegated to modal component
    async openAllocateModal(cell) {
        const employee = cell.dataset.employee;
        const day = cell.dataset.day;

        this.selectedCell = cell;

        // Call the modal to open with employee and day info
        await allocateHoursModal.open(employee, day, this.currentWeek);
    }

    // Handle allocation saved event from modal
    async handleAllocationSaved() {
        try {
            ModalManager.showLoading();
            
            // Refresh dashboard data
            await Promise.all([
                this.loadWeeklyAllocation(),
                this.dataService.getDashboardStats().then(stats => this.updateStats(stats)),
                this.loadAvailableTeamMembers()
            ]);
            
            ModalManager.hideLoading();
        } catch (error) {
            ModalManager.hideLoading();
            console.error('[DASHBOARD APP] Error refreshing after allocation:', error);
        }
    }

    openLogoutModal() {
        ModalManager.show('logoutModal');
    }

    handleLogout() {
        localStorage.removeItem('loggedUser');
        sessionStorage.clear();
        ModalManager.hide('logoutModal');
        ModalManager.showLoading();
        
        setTimeout(() => {
            window.location.href = "/login/HTML_Files/login.html";
        }, 500);
    }
}

// ============================================
// INITIALIZATION
// ============================================

let app;
document.addEventListener('DOMContentLoaded', () => {
    app = new DashboardApp();
    app.init();
});