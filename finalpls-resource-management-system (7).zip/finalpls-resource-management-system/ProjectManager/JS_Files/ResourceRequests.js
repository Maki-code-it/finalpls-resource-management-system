// PROJECT MANAGER (PM) Resource Requests.js
import { supabase } from "../../supabaseClient.js";


    async function updateUserNameDisplayEnhanced() {
        const userNameElement = document.getElementById('userName');
        if (!userNameElement) {
            console.warn('[USER DISPLAY] userName element not found');
            return;
        }

        try {
            const loggedUser = JSON.parse(localStorage.getItem('loggedUser') || '{}');
            
            if (loggedUser.name) {
                userNameElement.textContent = loggedUser.name;
                console.log('[USER DISPLAY] User name updated to:', loggedUser.name);
            } else if (loggedUser.email) {
                try {
                    const { data: userData, error } = await supabase
                        .from('users')
                        .select('name')
                        .eq('email', loggedUser.email)
                        .single();
                    
                    if (!error && userData && userData.name) {
                        userNameElement.textContent = userData.name;
                        loggedUser.name = userData.name;
                        localStorage.setItem('loggedUser', JSON.stringify(loggedUser));
                        console.log('[USER DISPLAY] User name fetched from Supabase:', userData.name);
                    } else {
                        userNameElement.textContent = loggedUser.email.split('@')[0];
                    }
                } catch (dbError) {
                    console.error('[USER DISPLAY] Error fetching from Supabase:', dbError);
                    userNameElement.textContent = loggedUser.email.split('@')[0];
                }
            } else {
                userNameElement.textContent = 'Project Manager';
                console.warn('[USER DISPLAY] No user information found');
            }
        } catch (error) {
            console.error('[USER DISPLAY] Error updating user name:', error);
            userNameElement.textContent = 'Project Manager';
        }
    }

// ============================================
// MODAL UTILITIES
// ============================================

class ModalManager {
    static show(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
    }

    static hide(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('active');
            document.body.style.overflow = '';
        }
    }

    static showLoading() {
        this.show('loadingOverlay');
    }

    static hideLoading() {
        this.hide('loadingOverlay');
    }
}

// ============================================
// MESSAGE UTILITIES
// ============================================

class MessageManager {
    static show(message, type = 'info') {
        const container = document.getElementById('messageContainer');
        if (!container) return;

        const messageBox = document.createElement('div');
        messageBox.className = `message-box ${type}`;

        const iconMap = {
            success: 'fa-check-circle',
            error: 'fa-exclamation-circle',
            warning: 'fa-exclamation-triangle',
            info: 'fa-info-circle'
        };

        const icon = document.createElement('i');
        icon.className = `fas ${iconMap[type]}`;

        const text = document.createElement('span');
        text.textContent = message;

        const closeBtn = document.createElement('button');
        closeBtn.className = 'message-close';
        closeBtn.innerHTML = '<i class="fas fa-times"></i>';
        closeBtn.addEventListener('click', () => messageBox.remove());

        messageBox.appendChild(icon);
        messageBox.appendChild(text);
        messageBox.appendChild(closeBtn);

        container.appendChild(messageBox);

        setTimeout(() => {
            messageBox.remove();
        }, 5000);
    }

    static success(message) {
        this.show(message, 'success');
    }

    static error(message) {
        this.show(message, 'error');
    }

    static warning(message) {
        this.show(message, 'warning');
    }

    static info(message) {
        this.show(message, 'info');
    }
}

// ============================================
// UTILITY FUNCTIONS
// ============================================

function formatDate(dateString) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function formatStatus(status) {
    const statusMap = {
        'pending': 'Pending',
        'approved': 'Approved',
        'rejected': 'Rejected',
        'fulfilled': 'Fulfilled',
        'cancelled': 'Cancelled'
    };
    return statusMap[status] || status;
}

function calculateDuration(startDate, endDate) {
    if (!startDate || !endDate) return 'N/A';
    const start = new Date(startDate);
    const end = new Date(endDate);
    const diffTime = Math.abs(end - start);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays === 1 ? '1 day' : `${diffDays} days`;
}

// ============================================
// DATA SERVICE
// ============================================

class PMDataService {
    constructor() {
        this.currentPMId = null;
        this.currentPMEmail = null;
    }

    async initialize() {
        const loggedUser = JSON.parse(localStorage.getItem('loggedUser') || '{}');
        
        if (loggedUser.email) {
            this.currentPMEmail = loggedUser.email;
            
            const { data: userData, error } = await supabase
                .from('users')
                .select('id, name, email')
                .eq('email', this.currentPMEmail)
                .eq('role', 'project_manager')
                .single();

            if (error) {
                console.error('[PM DATA SERVICE] Error fetching PM user:', error);
                throw error;
            }

            this.currentPMId = userData.id;
            console.log('[PM DATA SERVICE] Initialized for PM:', userData);
        } else {
            throw new Error('No logged in user found');
        }
    }

    async getProjects() {
        try {
            const { data, error } = await supabase
                .from('projects')
                .select('id, name, description, status, start_date, end_date')
                .eq('created_by', this.currentPMId)
                .order('created_at', { ascending: false });

            if (error) throw error;
            return data || [];
        } catch (error) {
            console.error('[PM DATA SERVICE] Error fetching projects:', error);
            return [];
        }
    }

    async getResourceRequests() {
        try {
            const { data, error } = await supabase
                .from('resource_requests')
                .select(`
                    id,
                    status,
                    requested_at,
                    approved_at,
                    notes,
                    start_date,
                    end_date,
                    duration_days,
                    projects (
                        id,
                        name,
                        description
                    ),
                    project_requirements (
                        id,
                        experience_level,
                        quantity_needed,
                        required_skills,
                        preferred_assignment_type
                    )
                `)
                .eq('requested_by', this.currentPMId)
                .order('requested_at', { ascending: false });

            if (error) throw error;
            console.log('[PM DATA SERVICE] Resource requests fetched:', data);
            return data || [];
        } catch (error) {
            console.error('[PM DATA SERVICE] Error fetching resource requests:', error);
            return [];
        }
    }

    async createResourceRequest(requestData) {
        try {
            // First, create project requirements
            const requirementIds = [];
            
            for (const resource of requestData.resources) {
                const { data: requirement, error: reqError } = await supabase
                    .from('project_requirements')
                    .insert({
                        project_id: requestData.projectId,
                        experience_level: resource.experienceLevel,
                        quantity_needed: resource.quantity,
                        required_skills: resource.skills,
                        preferred_assignment_type: resource.assignmentType
                    })
                    .select()
                    .single();

                if (reqError) throw reqError;
                requirementIds.push(requirement.id);
            }

            // Create resource request
            const { data: request, error: requestError } = await supabase
                .from('resource_requests')
                .insert({
                    project_id: requestData.projectId,
                    requirement_id: requirementIds[0], // Link to first requirement
                    requested_by: this.currentPMId,
                    status: 'pending',
                    notes: requestData.notes || null,
                    start_date: requestData.startDate,
                    end_date: requestData.endDate,
                    duration_days: requestData.durationDays
                })
                .select()
                .single();

            if (requestError) throw requestError;

            console.log('[PM DATA SERVICE] Resource request created:', request);
            return request;
        } catch (error) {
            console.error('[PM DATA SERVICE] Error creating resource request:', error);
            throw error;
        }
    }
}

// ============================================
// RESOURCE REQUESTS APP
// ============================================

class ResourceRequestsApp {
    constructor() {
        this.dataService = new PMDataService();
        this.allRequests = [];
        this.projects = [];
        this.resourceRowCount = 0;
    }

    async init() {
        try {
            ModalManager.showLoading();
            
            await this.dataService.initialize();

            await updateUserNameDisplayEnhanced();

            
            this.setupEventListeners();
            await this.loadProjects();
            await this.loadRequests();
            
            ModalManager.hideLoading();
        } catch (error) {
            ModalManager.hideLoading();
            console.error('[RESOURCE REQUESTS APP] Initialization error:', error);
            MessageManager.error('Failed to initialize. Please login again.');
            setTimeout(() => {
                window.location.href = "/login/HTML_Files/login.html";
            }, 2000);
        }
    }

    setupEventListeners() {
        // Logout button
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => this.openLogoutModal());
        }

        // New request button
        const newRequestBtn = document.getElementById('newRequestBtn');
        if (newRequestBtn) {
            newRequestBtn.addEventListener('click', () => this.openNewRequestModal());
        }

        // Status filter
        const statusFilter = document.getElementById('requestStatusFilter');
        if (statusFilter) {
            statusFilter.addEventListener('change', () => this.filterRequests());
        }

        // New request modal
        const closeRequestModal = document.getElementById('closeRequestModal');
        const cancelFormBtn = document.getElementById('cancelFormBtn');
        const requestForm = document.getElementById('requestForm');

        if (closeRequestModal) {
            closeRequestModal.addEventListener('click', () => ModalManager.hide('newRequestModal'));
        }
        if (cancelFormBtn) {
            cancelFormBtn.addEventListener('click', () => ModalManager.hide('newRequestModal'));
        }
        if (requestForm) {
            requestForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.submitRequest();
            });
        }

        // Add resource button
        const addResourceBtn = document.getElementById('addResourceBtn');
        if (addResourceBtn) {
            addResourceBtn.addEventListener('click', () => this.addResourceRow());
        }

        // Detail modal
        const closeDetailModal = document.getElementById('closeDetailModal');
        const closeDetailBtn = document.getElementById('closeDetailBtn');
        
        if (closeDetailModal) {
            closeDetailModal.addEventListener('click', () => ModalManager.hide('requestDetailModal'));
        }
        if (closeDetailBtn) {
            closeDetailBtn.addEventListener('click', () => ModalManager.hide('requestDetailModal'));
        }

        // Logout modal
        const cancelLogout = document.getElementById('cancelLogout');
        const confirmLogout = document.getElementById('confirmLogout');
        
        if (cancelLogout) {
            cancelLogout.addEventListener('click', () => ModalManager.hide('logoutModal'));
        }
        if (confirmLogout) {
            confirmLogout.addEventListener('click', () => this.handleLogout());
        }

        // View request buttons (delegated)
        document.addEventListener('click', (e) => {
            if (e.target.closest('.btn-view')) {
                const card = e.target.closest('.request-card');
                if (card) {
                    const requestId = parseInt(card.dataset.id);
                    this.viewRequestDetail(requestId);
                }
            }
        });

        // Close modals on overlay click
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) {
                    overlay.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        });
    }

    async loadProjects() {
        try {
            this.projects = await this.dataService.getProjects();
            this.populateProjectDropdown();
        } catch (error) {
            console.error('[RESOURCE REQUESTS APP] Error loading projects:', error);
            MessageManager.error('Failed to load projects');
        }
    }

    populateProjectDropdown() {
        const projectSelect = document.getElementById('projectSelect');
        if (!projectSelect) return;

        projectSelect.innerHTML = '<option value="">Select a project</option>';
        
        this.projects.forEach(project => {
            const option = document.createElement('option');
            option.value = project.id;
            option.textContent = `${project.name} - ${project.status}`;
            option.dataset.endDate = project.end_date || '';
            option.dataset.startDate = project.start_date || '';
            projectSelect.appendChild(option);
        });

        // Add change listener to auto-fill end dates
        projectSelect.addEventListener('change', (e) => {
            this.onProjectSelected(e.target.value);
        });
    }

    onProjectSelected(projectId) {
        if (!projectId) {
            // Clear all date fields if no project selected
            document.querySelectorAll('.resource-end-date').forEach(input => {
                input.value = '';
            });
            return;
        }

        const projectSelect = document.getElementById('projectSelect');
        const selectedOption = projectSelect.querySelector(`option[value="${projectId}"]`);
        
        if (selectedOption) {
            const projectEndDate = selectedOption.dataset.endDate;
            const projectStartDate = selectedOption.dataset.startDate;

            // Auto-fill all resource end dates with project end date
            document.querySelectorAll('.resource-end-date').forEach(input => {
                if (projectEndDate) {
                    input.value = projectEndDate;
                }
            });

            // Optionally set minimum start date to project start date
            document.querySelectorAll('.resource-start-date').forEach(input => {
                if (projectStartDate) {
                    input.min = projectStartDate;
                }
                if (projectEndDate) {
                    input.max = projectEndDate;
                }
            });

            // Set maximum end date to project end date
            document.querySelectorAll('.resource-end-date').forEach(input => {
                if (projectEndDate) {
                    input.max = projectEndDate;
                }
                if (projectStartDate) {
                    input.min = projectStartDate;
                }
            });
        }
    }

    async loadRequests() {
        try {
            this.allRequests = await this.dataService.getResourceRequests();
            this.renderRequests(this.allRequests);
        } catch (error) {
            console.error('[RESOURCE REQUESTS APP] Error loading requests:', error);
            MessageManager.error('Failed to load resource requests');
        }
    }

    renderRequests(requests) {
        const requestsList = document.getElementById('requestsList');
        if (!requestsList) return;

        requestsList.innerHTML = '';

        if (requests.length === 0) {
            requestsList.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-inbox"></i>
                    <h3>No Resource Requests</h3>
                    <p>Create your first resource request to get started</p>
                </div>
            `;
            return;
        }

        requests.forEach(request => {
            const card = this.createRequestCard(request);
            requestsList.appendChild(card);
        });
    }

    createRequestCard(request) {
        const template = document.getElementById('requestCardTemplate');
        const card = document.createElement('div');
        card.className = 'request-card';
        card.dataset.id = request.id;
        card.dataset.status = request.status;
        card.innerHTML = template.innerHTML;

        // Project name
        const projectName = card.querySelector('.request-project-name');
        if (projectName) {
            projectName.textContent = request.projects?.name || 'Unknown Project';
        }

        // Meta information
        const metaProject = card.querySelector('.meta-project');
        const metaDate = card.querySelector('.meta-date');
        const metaResources = card.querySelector('.meta-resources');

        if (metaProject) {
            metaProject.textContent = request.projects?.name || 'N/A';
        }
        if (metaDate) {
            metaDate.textContent = formatDate(request.requested_at);
        }
        if (metaResources) {
            const totalQuantity = request.project_requirements?.quantity_needed || 0;
            metaResources.textContent = `${totalQuantity} resource(s)`;
        }

        // Status
        const statusElem = card.querySelector('.request-status');
        if (statusElem) {
            statusElem.textContent = formatStatus(request.status);
            statusElem.className = `request-status ${request.status}`;
        }

        // Skills
        const skillsContainer = card.querySelector('.skills-tags');
        if (skillsContainer && request.project_requirements?.required_skills) {
            const skills = request.project_requirements.required_skills;
            skillsContainer.innerHTML = skills.map(skill => 
                `<span class="skill-tag">${skill}</span>`
            ).join('');
        }

        // Timeline
        const timelineValue = card.querySelector('.timeline-value');
        if (timelineValue) {
            timelineValue.textContent = request.project_requirements?.preferred_assignment_type || 'Full-Time';
        }

        // Duration
        const durationValue = card.querySelector('.duration-value');
        if (durationValue) {
            durationValue.textContent = calculateDuration(request.start_date, request.end_date);
        }

        // Start date
        const startDateValue = card.querySelector('.start-date-value');
        if (startDateValue) {
            startDateValue.textContent = formatDate(request.start_date);
        }

        // End date
        const endDateValue = card.querySelector('.end-date-value');
        if (endDateValue) {
            endDateValue.textContent = formatDate(request.end_date);
        }

        return card;
    }

    filterRequests() {
        const status = document.getElementById('requestStatusFilter').value;
        
        let filteredRequests = this.allRequests;

        if (status) {
            filteredRequests = filteredRequests.filter(req => req.status === status);
        }

        this.renderRequests(filteredRequests);
    }

    openNewRequestModal() {
        // Reset form
        const form = document.getElementById('requestForm');
        if (form) form.reset();

        // Clear resource rows
        const container = document.getElementById('resourceRowsContainer');
        if (container) {
            container.innerHTML = '';
            this.resourceRowCount = 0;
        }

        // Add first resource row
        this.addResourceRow();

        ModalManager.show('newRequestModal');
    }

    addResourceRow() {
        const template = document.getElementById('resourceRowTemplate');
        const container = document.getElementById('resourceRowsContainer');
        
        if (!template || !container) return;

        this.resourceRowCount++;
        
        const resourceRow = document.createElement('div');
        resourceRow.className = 'resource-row';
        resourceRow.dataset.rowId = this.resourceRowCount;
        resourceRow.innerHTML = template.innerHTML;

        // Update title
        const title = resourceRow.querySelector('.resource-row-title');
        if (title) {
            title.textContent = `Resource #${this.resourceRowCount}`;
        }

        // Show remove button if not first row
        if (this.resourceRowCount > 1) {
            const removeBtn = resourceRow.querySelector('.btn-remove-resource');
            if (removeBtn) {
                removeBtn.style.display = 'inline-flex';
                removeBtn.addEventListener('click', () => {
                    resourceRow.remove();
                    this.updateResourceRowTitles();
                });
            }
        }

        container.appendChild(resourceRow);

        // Auto-fill dates if project is already selected
        const projectSelect = document.getElementById('projectSelect');
        if (projectSelect && projectSelect.value) {
            this.onProjectSelected(projectSelect.value);
        }
    }

    updateResourceRowTitles() {
        const rows = document.querySelectorAll('.resource-row');
        rows.forEach((row, index) => {
            const title = row.querySelector('.resource-row-title');
            if (title) {
                title.textContent = `Resource #${index + 1}`;
            }
        });
        this.resourceRowCount = rows.length;
    }

    async submitRequest() {
        const projectId = document.getElementById('projectSelect').value;
        
        if (!projectId) {
            MessageManager.error('Please select a project');
            return;
        }

        // Collect resource data
        const resourceRows = document.querySelectorAll('.resource-row');
        const resources = [];
        
        for (const row of resourceRows) {
            const position = row.querySelector('.resource-position').value.trim();
            const quantity = parseInt(row.querySelector('.resource-quantity').value);
            const experienceLevel = row.querySelector('.resource-skill-level').value;
            const assignmentType = row.querySelector('.resource-assignment-type').value;
            const skillsInput = row.querySelector('.resource-skills').value.trim();
            const startDate = row.querySelector('.resource-start-date').value;
            const endDate = row.querySelector('.resource-end-date').value;
            const justification = row.querySelector('.resource-justification').value.trim();

            if (!position || !skillsInput || !startDate || !endDate) {
                MessageManager.error('Please fill in all required fields for each resource');
                return;
            }

            const skills = skillsInput.split(',').map(s => s.trim()).filter(s => s);

            resources.push({
                position,
                quantity,
                experienceLevel,
                assignmentType,
                skills,
                startDate,
                endDate,
                justification
            });
        }

        if (resources.length === 0) {
            MessageManager.error('Please add at least one resource');
            return;
        }

        // Calculate duration
        const firstResource = resources[0];
        const start = new Date(firstResource.startDate);
        const end = new Date(firstResource.endDate);
        const durationDays = Math.ceil((end - start) / (1000 * 60 * 60 * 24));

        const requestData = {
            projectId: parseInt(projectId),
            resources: resources,
            startDate: firstResource.startDate,
            endDate: firstResource.endDate,
            durationDays: durationDays,
            notes: resources.map(r => r.justification).filter(j => j).join('\n\n')
        };

        try {
            ModalManager.hide('newRequestModal');
            ModalManager.showLoading();

            await this.dataService.createResourceRequest(requestData);
            await this.loadRequests();

            ModalManager.hideLoading();
            MessageManager.success('Resource request submitted successfully!');
        } catch (error) {
            ModalManager.hideLoading();
            console.error('Error submitting request:', error);
            MessageManager.error('Failed to submit request: ' + error.message);
        }
    }

    viewRequestDetail(requestId) {
        const request = this.allRequests.find(r => r.id === requestId);
        if (!request) return;

        // Project information
        document.getElementById('detailProjectName').textContent = request.projects?.name || 'N/A';
        document.getElementById('detailProjectDesc').textContent = request.projects?.description || 'No description';

        // Status
        const statusElem = document.getElementById('detailStatus');
        statusElem.textContent = formatStatus(request.status);
        statusElem.className = `request-status ${request.status}`;

        // Timeline
        document.getElementById('detailSubmitted').textContent = formatDate(request.requested_at);
        document.getElementById('detailStartDate').textContent = formatDate(request.start_date);
        document.getElementById('detailEndDate').textContent = formatDate(request.end_date);
        document.getElementById('detailDuration').textContent = calculateDuration(request.start_date, request.end_date);

        // Show approved date if applicable
        const approvedRow = document.getElementById('detailApprovedRow');
        if (request.approved_at) {
            approvedRow.style.display = 'flex';
            document.getElementById('detailApproved').textContent = formatDate(request.approved_at);
        } else {
            approvedRow.style.display = 'none';
        }

        // Requirements table
        const tbody = document.getElementById('requirementsTableBody');
        tbody.innerHTML = '';
        
        if (request.project_requirements) {
            const req = request.project_requirements;
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${req.quantity_needed || 1}</td>
                <td><span class="experience-badge ${req.experience_level}">${req.experience_level}</span></td>
                <td>${req.preferred_assignment_type || 'Full-Time'}</td>
                <td>
                    <div class="skills-tags">
                        ${(req.required_skills || []).map(skill => 
                            `<span class="skill-tag">${skill}</span>`
                        ).join('')}
                    </div>
                </td>
            `;
            tbody.appendChild(row);
        }

        // Notes
        document.getElementById('detailNotes').textContent = request.notes || 'No additional notes';

        ModalManager.show('requestDetailModal');
    }

    openLogoutModal() {
        ModalManager.show('logoutModal');
    }

    handleLogout() {
        localStorage.removeItem('loggedUser');
        sessionStorage.clear();
        ModalManager.hide('logoutModal');
        ModalManager.showLoading();
        
        setTimeout(() => {
            window.location.href = "/login/HTML_Files/login.html";
        }, 500);
    }
}

// ============================================
// INITIALIZATION
// ============================================

let app;
document.addEventListener('DOMContentLoaded', () => {
    app = new ResourceRequestsApp();
    app.init();
});