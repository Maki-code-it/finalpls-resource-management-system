import os
import re
import tempfile
import logging
from fastapi import APIRouter, UploadFile, File
from PyPDF2 import PdfReader
from pdf2image import convert_from_path
import pytesseract
from docx import Document
from typing import List
from io import BytesIO
from PIL import Image
import spacy

# ---------- CONFIG ----------
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
POPPLER_PATH = r"C:\poppler-24.08.0\Library\bin"
nlp = spacy.load("en_core_web_sm")

# ---------- HARD-CODED SKILLS ----------
SKILL_KEYWORDS = [
    "Python", "Java", "JavaScript", "React", "SQL", "NoSQL",
    "API Design", "Project Management", "Agile", "Scrum", "System Architecture",
    "Leadership", "Teamwork", "Communication", "Machine Learning"
]

# ---------- SYNONYMS AND COMMON FRAMEWORKS ----------
SKILL_SYNONYMS = {
    "JS": "JavaScript",
    "PM": "Project Management",
    "ML": "Machine Learning",
    "DB": "SQL",
    "PyTorch": "PyTorch",
}

COMMON_FRAMEWORKS = [
    "Django", "Flask", "FastAPI", "Vue", "Angular", "Node.js", "Express", "Spring Boot"
]

# ---------- TECH TERMS FOR NLP FALLBACK ----------
TECH_TERMS = set([
    "Python", "Java", "JavaScript", "React", "SQL", "NoSQL",
    "Django", "Flask", "FastAPI", "Vue", "Angular", "Node.js", "Express",
    "Spring Boot", "PyTorch", "TensorFlow", "Keras", "Docker", "Kubernetes",
    "Terraform", "AWS", "GCP", "Azure", "MongoDB", "PostgreSQL", "MySQL"
])

# ---------- LOGGING ----------
logging.basicConfig(level=logging.DEBUG, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

router = APIRouter()

# ---------- TEXT EXTRACTION HELPERS ----------
def extract_text_from_pdf(pdf_path):
    text = ""
    try:
        logger.debug(f"Converting PDF to images: {pdf_path}")
        images = convert_from_path(pdf_path, poppler_path=POPPLER_PATH)
        logger.debug(f"Converted {len(images)} pages to images.")

        for i, img in enumerate(images):
            page_text = pytesseract.image_to_string(img)
            logger.debug(f"Page {i+1} text length: {len(page_text)}")
            text += page_text + "\n"
    except Exception as e:
        logger.error(f"PDF OCR extraction failed: {e}")
    return text.strip()

def extract_text_from_docx(docx_file):
    text = ""
    try:
        logger.debug("Extracting text from DOCX")
        doc = Document(docx_file)
        for p in doc.paragraphs:
            if p.text.strip():
                text += p.text + "\n"
        for table in doc.tables:
            for row in table.rows:
                row_text = " ".join(cell.text.strip() for cell in row.cells if cell.text.strip())
                if row_text:
                    text += row_text + "\n"
    except Exception as e:
        logger.error(f"DOCX extraction failed: {e}")
    return text

def clean_ocr_text(text):
    headings = [
        "Personal Information", "Education", "Skills", "Experience",
        "Work Experience", "Projects", "Certifications", "Summary"
    ]
    for h in headings:
        text = text.replace(h, "")
    text = re.sub(r'\n+', '\n', text)
    text = re.sub(r'\s{2,}', ' ', text)
    return text.strip()

# ---------- PERSONAL INFO EXTRACTION ----------
def extract_personal_info(text):
    info = {}
    text = clean_ocr_text(text)
    lines = text.split("\n")
    for line in lines:
        line_lower = line.lower()
        if "full name" in line_lower:
            match = re.search(r"Full Name[:\s]*(.+)", line, re.IGNORECASE)
            if match: info["Full Name"] = match.group(1).strip()
        elif "employee id" in line_lower or re.search(r"\bID\b", line):
            match = re.search(r"(Employee ID|ID)[:\s]*(.+)", line, re.IGNORECASE)
            if match: info["Employee ID"] = match.group(2).strip()
        elif "email" in line_lower:
            match = re.search(r"[\w\.-]+@[\w\.-]+", line)
            if match: info["Email"] = match.group()
        elif "phone" in line_lower or re.search(r"\+?\d{9,}", line):
            match = re.search(r"(\+?\d[\d\s\-]{8,}\d)", line)
            if match: info["Phone Number"] = match.group()
        elif "location" in line_lower:
            match = re.search(r"Location[:\s]*(.+)", line, re.IGNORECASE)
            if match: info["Location"] = match.group(1).strip()

    # NLP fallback
    doc = nlp(text)
    if "Full Name" not in info:
        names = [ent.text for ent in doc.ents if ent.label_ == "PERSON"]
        if names: info["Full Name"] = names[0]
    if "Location" not in info:
        locations = [ent.text for ent in doc.ents if ent.label_ == "GPE"]
        if locations: info["Location"] = locations[0]
    if "Organization" not in info:
        orgs = [ent.text for ent in doc.ents if ent.label_ == "ORG"]
        if orgs: info["Organization"] = orgs[0]

    logger.debug(f"Extracted personal info: {info}")
    return info

# ---------- DYNAMIC SKILL EXTRACTION ----------
def extract_skills_dynamic(text):
    found_skills = set()
    text_lower = text.lower()

    # 1. Exact matches from SKILL_KEYWORDS
    for skill in SKILL_KEYWORDS:
        if re.search(r'\b' + re.escape(skill.lower()) + r'\b', text_lower):
            found_skills.add(skill)

    # 2. Common frameworks
    for fw in COMMON_FRAMEWORKS:
        if re.search(r'\b' + re.escape(fw.lower()) + r'\b', text_lower):
            found_skills.add(fw)

    # 3. Synonyms / abbreviations
    for syn, actual in SKILL_SYNONYMS.items():
        if re.search(r'\b' + re.escape(syn.lower()) + r'\b', text_lower):
            found_skills.add(actual)

    # 4. NLP fallback: only include known TECH_TERMS
    doc = nlp(text)
    for token in doc:
        token_clean = token.text.strip()
        if token_clean in TECH_TERMS:
            found_skills.add(token_clean)

    return sorted(found_skills)

# ---------- MAIN ROUTE ----------
@router.post("/extract_skills/")
async def extract_skills_endpoint(files: List[UploadFile] = File(...)):
    results = []

    for file in files:
        content = await file.read()
        suffix = os.path.splitext(file.filename)[1].lower()
        text = ""

        print(f"\n[INFO] Processing file: {file.filename} (type: {suffix})", flush=True)

        try:
            # Extract text
            if suffix == ".pdf":
                with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp_pdf:
                    tmp_pdf.write(content)
                    tmp_pdf.flush()
                    tmp_pdf_path = tmp_pdf.name

                text = extract_text_from_pdf(tmp_pdf_path)
                os.unlink(tmp_pdf_path)

            elif suffix == ".docx":
                docx_file = BytesIO(content)
                text = extract_text_from_docx(docx_file)

            elif suffix in [".png", ".jpg", ".jpeg"]:
                img = Image.open(BytesIO(content))
                text = pytesseract.image_to_string(img)

            else:
                print(f"[WARNING] Unsupported file type: {file.filename}", flush=True)
                continue

            if not text.strip():
                print(f"[WARNING] No text extracted from {file.filename}", flush=True)

            # Extract personal info
            personal_info = extract_personal_info(text)

            # Extract skills dynamically
            skills = extract_skills_dynamic(text)
            print(f"[INFO] Skills found in {file.filename}: {skills}", flush=True)

            results.append({
                "filename": file.filename,
                "personal_info": personal_info,
                "skills": skills
            })

        except Exception as e:
            print(f"[ERROR] Error processing file {file.filename}: {e}", flush=True)

    # Combine all skills
    all_skills = sorted(set(skill for r in results for skill in r["skills"]))
    print(f"[INFO] Total unique skills found: {all_skills}", flush=True)

    return {
        "results": results,
        "skills": all_skills
    }
